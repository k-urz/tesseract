# Experimental component pack

Config `66aebc68e650eb46`; all dimensions mm. Process/material unselected.

## What this pack establishes

- A two-stage tube test assigned to **E21**; housing length 170.278 mm.
- Removable transverse stop pin, closed outer end and separate friction adjustment screw.
- Split socket/ball test and a rigid four-direction layout gauge at V0.
- Per-side clearance coupons labelled by filename. Use the supplied inner rod to compare fits.

## Assembly and measurements

1. Inspect STEP dimensions, STL units, wall thickness and the chosen supplier's process limits.
2. Make one fit coupon and one short rod first. Record process, material, orientation and finish.
3. Deburr/finish the bore as appropriate; insert the inner rod BEFORE installing its transverse stop pin.
4. Install the stop pin through the slots and inner cross-hole; use washers and a nut. Check the two end stops and retained overlap.
5. Fit the friction screw in its separate boss. The screw presses the inner rod; do not cut printed threads by assumption.
6. Place the ball between the socket halves and install two screws/nuts. Tighten incrementally; check freedom, retention and material deformation.
7. Record the force to start/continue motion, holding force, backlash, available stroke and socket angle before and after repeated use.
8. Use the hub as a static placement gauge only. Design the articulated hub and rod adapters after these measurements.

`manifest.json` records failed edge packaging checks, required direction changes, sampled stem/socket intersections and the larger post-CAD envelopes. They remain design blockers until resolved. The pack is NOT a complete tesseract assembly.
